Hello!

Here you have omniflop images of my personal lo-fi drum samples collection for Akai S series samplers.
These are s1000 disk format and it can be used with akai s950 s1000 s1100 s2000 s3000 s5000 and many others devices.

All samples are recorded, processed by me.
You can use it with no restrictions as components of musical compositions
either private or commercial.
BUT you are not allowed to redistribute, sell. ASK ME FIRST!

Check out my website for more free stuff: http://www.martin78.com

(C) 2014 Martin78.com for recording and processing.  
